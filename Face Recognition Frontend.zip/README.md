
  # Face Recognition Frontend

  This is a code bundle for Face Recognition Frontend. The original project is available at https://www.figma.com/design/zytVHCY2Qk2ShK5t4Ltsuw/Face-Recognition-Frontend.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  